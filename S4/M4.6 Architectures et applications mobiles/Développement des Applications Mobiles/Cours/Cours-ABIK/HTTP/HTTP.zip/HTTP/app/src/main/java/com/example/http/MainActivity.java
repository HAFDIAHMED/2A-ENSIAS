package com.example.http;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    String str="";
    EditText tv;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (EditText) this.findViewById(R.id.text);
        bt = (Button) this.findViewById(R.id.button);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {


                        try {
                            str = charger_Url("http://ensias.um5.ac.ma/");
                        } catch (IOException e) {
                            e.printStackTrace();

                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (str.length()>=1)   tv.setText(str);

                            }});
                    }
                }).start();
            }


        });

    }

    private String charger_Url(String str_url) throws IOException {
        InputStream is = null;
        HttpURLConnection conn;
        String contentAsString="";
        URL url = new URL(str_url);
        conn = (HttpURLConnection) url.openConnection();
        // Starts the query
        conn.connect();
         if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            int response = conn.getResponseCode();
            is = conn.getInputStream();
            // Convert the InputStream into a string
            contentAsString = lire_stream(is);
        }

        is.close();
        conn.disconnect();
        return contentAsString;
    }

    public String lire_stream(InputStream stream) throws IOException, UnsupportedEncodingException {
        StringBuilder builder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line + "\n");
        }
        return builder.toString();
    }


}
